package com.chesscoach.mobile

import android.app.Activity
import android.os.Bundle
import android.util.Base64
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.widget.FrameLayout
import java.io.BufferedReader
import java.io.InputStreamReader

/** Android WebView host that injects the ChessCoach UI into the Chess.com website. */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var injectedUrl: String? = null

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (url.contains("chess.com") && injectedUrl != url) {
                        injectedUrl = url
                        injectChessCoach()
                    }
                }
            }
            loadUrl("https://www.chess.com/")
        }
        setContentView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }

    private fun readAsset(path: String): String = assets.open(path).use { input ->
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
    }

    private fun jsString(source: String): String =
        "(function(){try{(0,eval)(atob('${Base64.encodeToString(source.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)}'));}catch(e){console.error('ChessCoach injection error',e);}})();"

    private fun injectChessCoach() {
        // Minimal Manifest-V3 compatibility layer: persistent local settings and resource URLs.
        val shim = """
            window.chrome = window.chrome || {};
            chrome.runtime = chrome.runtime || {};
            chrome.runtime.id = 'chesscoach-android';
            chrome.runtime.lastError = null;
            chrome.runtime.getURL = function(p){ return 'file:///android_asset/chesscoach/' + p; };
            chrome.runtime.sendMessage = function(msg, cb){
              const result = {ok:false, unavailable:true, message:'Background extension service is not ported to Android'};
              if (typeof cb === 'function') setTimeout(()=>cb(result),0);
            };
            chrome.storage = chrome.storage || {};
            chrome.storage.local = {
              get: function(keys, cb){
                const out = {};
                if (keys == null) { for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);try{out[k]=JSON.parse(localStorage.getItem(k));}catch(e){out[k]=localStorage.getItem(k);}} }
                else if (Array.isArray(keys)) keys.forEach(k=>{let v=localStorage.getItem(k);if(v!==null){try{out[k]=JSON.parse(v)}catch(e){out[k]=v}}});
                else if (typeof keys === 'string') {let v=localStorage.getItem(keys);if(v!==null){try{out[keys]=JSON.parse(v)}catch(e){out[keys]=v}}}
                else Object.keys(keys).forEach(k=>{let v=localStorage.getItem(k);if(v!==null){try{out[k]=JSON.parse(v)}catch(e){out[k]=v}}else out[k]=keys[k]});
                if(typeof cb==='function') setTimeout(()=>cb(out),0); return Promise.resolve(out);
              },
              set: function(obj, cb){Object.keys(obj||{}).forEach(k=>localStorage.setItem(k,JSON.stringify(obj[k])));if(typeof cb==='function')setTimeout(cb,0);return Promise.resolve();},
              remove: function(keys, cb){(Array.isArray(keys)?keys:[keys]).forEach(k=>localStorage.removeItem(k));if(typeof cb==='function')setTimeout(cb,0);return Promise.resolve();},
              clear: function(cb){localStorage.clear();if(typeof cb==='function')setTimeout(cb,0);return Promise.resolve();}
            };
        """.trimIndent()

        val css = readAsset("chesscoach/content/content.css")
        val styleInstall = "(function(){if(document.getElementById('cc-android-style'))return;var s=document.createElement('style');s.id='cc-android-style';s.textContent=atob('${Base64.encodeToString(css.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)}');(document.head||document.documentElement).appendChild(s);})();"
        webView.evaluateJavascript(jsString(shim), null)
        webView.evaluateJavascript(styleInstall, null)
        // Libraries are loaded before the main content script, matching manifest order.
        listOf("chesscoach/lib/openings.js", "chesscoach/lib/explainer.js", "chesscoach/lib/phonk-fx.js", "chesscoach/content/content.js").forEach { path ->
            webView.evaluateJavascript(jsString(readAsset(path)), null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
