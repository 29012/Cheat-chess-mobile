package com.chesscoach.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(28,28,28,28) }
        val title = TextView(this).apply { text="ChessCoach Mobile"; textSize=24f; gravity=Gravity.CENTER }
        val info = TextView(this).apply { text="Включи разрешение «Поверх других приложений». После этого появится плавающая кнопка CC поверх официального Chess.com."; textSize=16f; gravity=Gravity.CENTER; setPadding(0,24,0,24) }
        val permission = Button(this).apply { text="Разрешить отображение поверх приложений"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 71)
            } else startOverlayAndOpenChess()
        } }
        val open = Button(this).apply { text="Открыть Chess.com"; setOnClickListener { if (Settings.canDrawOverlays(this@MainActivity)) startOverlayAndOpenChess() else Toast.makeText(this@MainActivity,"Сначала разреши отображение поверх приложений",Toast.LENGTH_LONG).show() } }
        layout.addView(title); layout.addView(info); layout.addView(permission); layout.addView(open)
        setContentView(layout)
    }

    private fun startOverlayAndOpenChess() {
        if (!Settings.canDrawOverlays(this)) return
        startService(Intent(this, OverlayMenuService::class.java))
        val launch = packageManager.getLaunchIntentForPackage("com.chess")
        if (launch != null) startActivity(launch)
        else {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.chess.com/"))
            startActivity(web)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 71 && Settings.canDrawOverlays(this)) startOverlayAndOpenChess()
    }
}
