package com.chesscoach.mobile

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import android.content.Context

class OverlayMenuService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams

    private fun lp(width: Int, height: Int): WindowManager.LayoutParams = WindowManager.LayoutParams(
        width, height,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 220 }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun bg(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "CC"; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; background = bg(Color.rgb(24, 30, 44), 60f)
            elevation = 12f
            setOnClickListener { togglePanel() }
        }
        bubbleParams = lp(dp(54), dp(54))
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; true }
                MotionEvent.ACTION_MOVE -> { bubbleParams.x=ox+(e.rawX-sx).toInt(); bubbleParams.y=oy+(e.rawY-sy).toInt(); try { wm.updateViewLayout(b,bubbleParams) } catch (_: Exception) {}; true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) togglePanel(); true }
                else -> false
            }
        }
        bubble = b
        wm.addView(b, bubbleParams)
    }

    private fun togglePanel() { if (panel == null) showPanel() else hidePanel() }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(Color.rgb(18, 23, 34), 24f); elevation = 18f
        }
        val title = TextView(this).apply {
            text = "CHESSCOACH"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); setPadding(0,0,0,dp(8))
        }
        box.addView(title)
        val subtitle = TextView(this).apply {
            text = "Меню поверх Chess.com"; textSize = 12f; setTextColor(Color.LTGRAY)
            setPadding(0,0,0,dp(10))
        }
        box.addView(subtitle)
        addRow(box, "Дебюты", "Каталог подключён к исходникам; Android-перенос ещё не готов.")
        addRow(box, "Объяснения ходов", "Требуется подключить распознавание позиции с экрана.")
        addRow(box, "Анализ позиции", "Пока недоступен в overlay-режиме.")
        addRow(box, "Настройки", "Плавающая панель работает. Полная синхронизация настроек ещё в разработке.")
        val close = Button(this).apply { text = "Свернуть"; setOnClickListener { hidePanel() } }
        box.addView(close)
        panelParams = lp(dp(280), WindowManager.LayoutParams.WRAP_CONTENT).apply { x = dp(76); y = 220 }
        panel = box
        wm.addView(box, panelParams)
    }

    private fun addRow(parent: LinearLayout, heading: String, detail: String) {
        val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
        val h = TextView(this).apply { text=heading; textSize=15f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val d = TextView(this).apply { text=detail; textSize=11f; setTextColor(Color.LTGRAY) }
        item.addView(h); item.addView(d); parent.addView(item)
    }

    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { hidePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
