package com.chesscoach.mobile

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import org.json.JSONObject

/** Android WebView host which loads the ChessCoach extension scripts into Chess.com. */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var injectionStarted = false

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            @Suppress("DEPRECATION")
            settings.allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            settings.allowUniversalAccessFromFileURLs = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (url.contains("chess.com", ignoreCase = true)) injectChessCoach()
                }
            }
            loadUrl("https://www.chess.com/")
        }
        root.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val badge = TextView(this).apply {
            text = "ChessCoach"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(16, 9, 16, 9)
            setBackgroundColor(0xCC151923.toInt())
        }
        val params = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.topMargin = 12
        params.leftMargin = 12
        root.addView(badge, params)
        setContentView(root)
    }

    private fun readAsset(path: String): String = assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun injectChessCoach() {
        if (injectionStarted) return
        injectionStarted = true
        try {
            val base = "file:///android_asset/chesscoach/"
            val shim = """
                (function(){
                  if (window.__ccAndroidShim) return;
                  window.__ccAndroidShim = true;
                  const listeners=[];
                  const store={};
                  try { Object.assign(store, JSON.parse(localStorage.getItem('__cc_storage')||'{}')); } catch(e){}
                  const storage={
                    get:function(keys, cb){
                      let out={};
                      if (keys == null) out={...store};
                      else if (Array.isArray(keys)) keys.forEach(k=>{if(k in store)out[k]=store[k];});
                      else if (typeof keys==='string') {if(keys in store)out[keys]=store[keys];}
                      else if (typeof keys==='object') Object.keys(keys).forEach(k=>out[k]=k in store?store[k]:keys[k]);
                      if(cb) setTimeout(()=>cb(out),0); return Promise.resolve(out);
                    },
                    set:function(obj, cb){Object.assign(store,obj||{});try{localStorage.setItem('__cc_storage',JSON.stringify(store));}catch(e){} if(cb)setTimeout(cb,0);return Promise.resolve();},
                    remove:function(keys,cb){(Array.isArray(keys)?keys:[keys]).forEach(k=>delete store[k]);try{localStorage.setItem('__cc_storage',JSON.stringify(store));}catch(e){}if(cb)cb();},
                    clear:function(cb){Object.keys(store).forEach(k=>delete store[k]);try{localStorage.removeItem('__cc_storage');}catch(e){}if(cb)cb();}
                  };
                  window.chrome=window.chrome||{};
                  window.chrome.runtime={id:'chesscoach-android',lastError:null,
                    getURL:function(p){return '__CC_BASE__' + String(p).replace(/^\\//,'');},
                    onMessage:{addListener:function(fn){listeners.push(fn);}},
                    sendMessage:function(msg, cb){let answered=false;const reply=v=>{if(answered)return;answered=true;if(cb)cb(v);};
                      for(const fn of listeners){try{const keep=fn(msg,{},reply);if(keep===true)return;}catch(e){console.error('[ChessCoach]',e);}}
                      if(!answered)reply(undefined);
                    }
                  };
                  window.chrome.storage={local:storage};
                })();
            """.trimIndent().replace("__CC_BASE__", base)
            val scripts = listOf(
                "lib/openings.js", "lib/explainer.js", "lib/phonk-fx.js",
                "background/background.js"
            )
            val combined = StringBuilder(shim)
            for (path in scripts) {
                combined.append("\n;\n").append(readAsset("chesscoach/$path")).append("\n;")
            }
            combined.append("\nwindow.__ccAndroidCssText=")
                .append(JSONObject.quote(readAsset("chesscoach/content/content.css")))
                .append(";\n")
                .append(readAsset("chesscoach/content/content.js"))
            webView.evaluateJavascript(combined.toString(), null)
        } catch (e: Exception) {
            injectionStarted = false
            android.util.Log.e("ChessCoach", "Extension injection failed", e)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
